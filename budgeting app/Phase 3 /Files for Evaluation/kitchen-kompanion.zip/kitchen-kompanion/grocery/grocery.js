document.addEventListener("DOMContentLoaded", function () {
    let templates = loadTemplates();
    let currentAddTarget = null;
    let currentEditTarget = null;

    initializeExistingItems();
    initializeCategories();
    attachModalEventListeners();
    attachGroceryListClickHandler();

    // If no categories exist, have a message saying there are no categories
    const groceryList = document.getElementById('grocery-list');
    if (groceryList && groceryList.children.length === 0) {
        const noCatMsg = document.createElement('p');
        noCatMsg.id = 'no-categories-msg';
        noCatMsg.textContent = 'No lists available. Please create a list or use one from templates to get started.';
        groceryList.parentNode.insertBefore(noCatMsg, groceryList);
    }

    // Remove no categories message when a category is added
    const observer = new MutationObserver(function (mutationsList) {
        for (const mutation of mutationsList) {
            if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                const noCatMsg = document.getElementById('no-categories-msg');
                if (noCatMsg) {
                    noCatMsg.remove();
                }
            }
        }
    });

    if (groceryList) {
        observer.observe(groceryList, { childList: true });
    }   

    // If all categories are removed, show no categories message
    const removalObserver = new MutationObserver(function (mutationsList) {
        for (const mutation of mutationsList) {
            if (mutation.type === 'childList' && mutation.removedNodes.length > 0) {
                if (groceryList.children.length === 0) {
                    const noCatMsg = document.createElement('p');
                    noCatMsg.id = 'no-categories-msg';
                    noCatMsg.textContent = 'No lists available. Please create a list or use one from templates to get started.';
                    groceryList.parentNode.insertBefore(noCatMsg, groceryList);
                }
            }
        }
    });

    if (groceryList) {
        removalObserver.observe(groceryList, { childList: true });
    }   

    // Initialize existing list items
    function initializeExistingItems() {
        document.querySelectorAll('.subcategory li').forEach(li => {
            convertToStructuredItem(li);
            addItemControls(li);
        });
    }

    // Initialize categories with add buttons and click handlers
    function initializeCategories() {
        document.querySelectorAll('.category').forEach(cat => {
            const subcategory = cat.querySelector('.subcategory');
            attachHeaderAddButton(cat, subcategory);
            attachSubcategoryClickHandler(subcategory);
        });``
    }

    // Handlers for new items added
    function attachGroceryListClickHandler() {
        const groceryList = document.getElementById('grocery-list');
        if (!groceryList) return;

        groceryList.addEventListener('click', function(e) {
            // Item edit button
            if (e.target.closest('.edit-btn')) {
                e.stopPropagation();
                const li = e.target.closest('li');
                openEditModal(li);
                return;
            }

            // Item trash button
            const itemTrash = e.target.closest('.subcategory li .trash');
            if (itemTrash) {
                e.stopPropagation();
                itemTrash.closest('li').remove();
                return;
            }

            // Item cross off
            const item = e.target.closest('.subcategory li');
            if (item && !e.target.closest('.item-controls')) {
                item.classList.toggle('checked');
                return;
            }

            // Add item to category
            if (e.target.closest('.add-item-header-btn')) {
                e.stopPropagation();
                const category = e.target.closest('.category');
                const subcategory = category.querySelector('.subcategory');
                openAddItemModal(subcategory);
                return;
            }

            // Category trash button
            const categoryTrash = e.target.closest('.category-header .trash');
            if (categoryTrash) {
                e.stopPropagation();
                categoryTrash.closest('.category').remove();
                return;
            }

            // Open/close category 
            if (e.target.classList.contains('dropdown') || e.target.closest('.dropdown')) {
                const category = e.target.closest('.category');
                if (category) {
                    category.classList.toggle('open');
                }
                return;
            }
        });
    }

    // Convert plain li to structured format
    function convertToStructuredItem(li) {
        if (li.querySelector('.item-name')) return;

        const name = li.dataset.name?.trim() || li.textContent.trim();
        const qty = li.dataset.qty ? Number(li.dataset.qty) : null;
        const price = li.dataset.price ? Number(li.dataset.price) : null;

        li.innerHTML = '';
        li.dataset.name = name;
        if (qty !== null) li.dataset.qty = qty;
        if (price !== null) li.dataset.price = price;

        const leftDiv = document.createElement('div');
        leftDiv.className = 'item-left';

        const nameSpan = document.createElement('span');
        nameSpan.className = 'item-name';
        nameSpan.textContent = name;
        leftDiv.appendChild(nameSpan);

        const metaDiv = createMetaDiv(qty, price);
        leftDiv.appendChild(metaDiv);
        li.appendChild(leftDiv);
    }

    // Create metadata display for qty and price
    function createMetaDiv(qty, price) {
        const meta = document.createElement('div');
        meta.className = 'item-meta';

        if (qty !== null) {
            const qtySpan = document.createElement('span');
            qtySpan.className = 'qty';
            qtySpan.textContent = `Qty: ${qty}`;
            meta.appendChild(qtySpan);
        }

        if (price !== null) {
            const priceSpan = document.createElement('span');
            priceSpan.className = 'price';
            priceSpan.textContent = `$${Number(price).toFixed(2)}`;
            meta.appendChild(priceSpan);
        }

        return meta;
    }

    // Add edit and delete controls to item
    function addItemControls(li) {
        if (li.querySelector('.item-controls')) return;

        const controls = document.createElement('span');
        controls.className = 'item-controls';

        const editBtn = createEditButton(li);
        const trashSpan = createTrashButton(li);

        controls.appendChild(editBtn);
        controls.appendChild(trashSpan);
        li.appendChild(controls);
    }

    // Create edit button
    function createEditButton(li) {
        const editBtn = document.createElement('button');
        editBtn.type = 'button';
        editBtn.className = 'edit-btn';
        editBtn.title = 'Edit item';
        editBtn.textContent = '✎';
        return editBtn;
    }

    // Create trash button
    function createTrashButton(li) {
        const trashSpan = document.createElement('span');
        trashSpan.className = 'trash';
        const img = document.createElement('img');
        img.src = "../icons/trash.png";
        img.alt = "Delete";
        img.style.width = "16px";
        img.style.height = "16px";
        trashSpan.appendChild(img);
        return trashSpan;
    }

    // Open edit modal
    function openEditModal(li) {
        currentEditTarget = li;
        currentAddTarget = null;
        document.getElementById('modal-item-name').value = li.dataset.name || '';
        document.getElementById('modal-item-qty').value = li.dataset.qty || '';
        document.getElementById('modal-item-price').value = li.dataset.price || '';
        document.getElementById('add-item-modal').style.display = 'flex';
    }

    // Attach add button to category header
    function attachHeaderAddButton(categoryLi, subcategory) {
        const header = categoryLi.querySelector('.category-header');
        if (!header || header.querySelector('.add-item-header-btn')) return;

        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'add-item-header-btn';
        btn.title = 'Add item';
        btn.textContent = '+';

        const trash = header.querySelector('.trash');
        header.insertBefore(btn, trash);
    }

    // Modal: Open add item
    window.openAddItemModal = function (subcategory) {
        currentAddTarget = subcategory;
        currentEditTarget = null;
        clearModalInputs();
        document.getElementById('add-item-modal').style.display = 'flex';
    };

    // Modal: Close add item
    window.closeAddItemModal = function () {
        document.getElementById('add-item-modal').style.display = 'none';
        currentAddTarget = null;
        currentEditTarget = null;
    };

    // Modal: Open new list
    window.openNewList = function () {
        document.getElementById('new-list-modal').style.display = 'flex';
        document.getElementById('new-list-name').value = '';
        document.getElementById('new-item-name').value = '';
        document.getElementById('new-item-qty').value = '';
        document.getElementById('new-item-price').value = '';
        document.getElementById('new-items-list').innerHTML = '';
    };

    // Modal: Close new list
    window.closeNewList = function () {
        document.getElementById('new-list-modal').style.display = 'none';
    };

    // Modal: Open templates
    window.openTemplates = function () {
        renderTemplatesList();
        document.getElementById('templates-modal').style.display = 'flex';
    };

    // Modal: Close templates
    window.closeTemplates = function () {
        document.getElementById('templates-modal').style.display = 'none';
    };

    // Clear modal input fields
    function clearModalInputs() {
        document.getElementById('modal-item-name').value = '';
        document.getElementById('modal-item-qty').value = '';
        document.getElementById('modal-item-price').value = '';
    }

    // Attach all modal event listeners
    function attachModalEventListeners() {
        // Add/Edit item modal
        document.getElementById('modal-add-item-btn')?.addEventListener('click', handleModalAddItem);

        // New list modal
        document.getElementById('add-new-item')?.addEventListener('click', handleAddNewItem);
        document.getElementById('create-new-list')?.addEventListener('click', handleCreateNewList);
        document.getElementById('save-as-template')?.addEventListener('click', handleSaveAsTemplate);
    }

    // Handle add/edit item in modal
    function handleModalAddItem() {
        const name = document.getElementById('modal-item-name').value.trim();
        if (!name) return;

        const qty = parseNumberInput('modal-item-qty');
        const price = parseNumberInput('modal-item-price');

        if (currentEditTarget) {
            updateExistingItem(currentEditTarget, name, qty, price);
        } else if (currentAddTarget) {
            addNewItem(currentAddTarget, { name, qty, price });
        }

        closeAddItemModal();
    }

    // Update existing item
    function updateExistingItem(li, name, qty, price) {
        li.dataset.name = name;
        updateDataset(li, 'qty', qty);
        updateDataset(li, 'price', price);

        const nameEl = li.querySelector('.item-name');
        if (nameEl) {
            nameEl.textContent = name;
        }

        const meta = li.querySelector('.item-meta');
        if (meta) {
            meta.innerHTML = '';
            meta.appendChild(createMetaDiv(qty, price));
        }
    }

    // Add new item to subcategory
    function addNewItem(subcategory, itemData) {
        const newLi = createItemElement(itemData);
        addItemControls(newLi);
        subcategory.appendChild(newLi);
    }

    // Handle adding item to new list modal
    function handleAddNewItem() {
        const name = document.getElementById('new-item-name').value.trim();
        if (!name) return;

        const qty = parseNumberInput('new-item-qty');
        const price = parseNumberInput('new-item-price');

        const li = createItemElement({ name, qty, price });
        const removeBtn = document.createElement('button');
        removeBtn.type = 'button';
        removeBtn.textContent = '×';
        removeBtn.className = 'trash';
        removeBtn.addEventListener('click', e => {
            e.stopPropagation();
            li.remove();
        });
        li.appendChild(removeBtn);

        document.getElementById('new-items-list').appendChild(li);
        document.getElementById('new-item-name').value = '';
        document.getElementById('new-item-qty').value = '';
        document.getElementById('new-item-price').value = '';
    }

    // Handle create new list
    function handleCreateNewList() {
        const name = document.getElementById('new-list-name').value.trim() || 'New List';
        const items = extractItemsFromModal();
        createCategory(name, items);
        closeNewList();
    }

    // Handle save as template
    function handleSaveAsTemplate() {
        const name = document.getElementById('new-list-name').value.trim() || 'Untitled Template';
        const items = extractItemsFromModal();
        
        templates.push({ name, items });
        saveTemplates(templates);
        closeNewList();
    }

    // Extract items from new list modal
    function extractItemsFromModal() {
        return Array.from(document.querySelectorAll('#new-items-list li')).map(li => ({
            name: li.dataset.name || li.textContent.trim(),
            qty: li.dataset.qty ? Number(li.dataset.qty) : null,
            price: li.dataset.price ? Number(li.dataset.price) : null
        }));
    }

    // Render templates list
    function renderTemplatesList() {
        const container = document.getElementById('templates-list');
        container.innerHTML = '';

        if (!templates.length) {
            container.textContent = 'No templates saved yet.';
            return;
        }

        templates.forEach((template, idx) => {
            const item = createTemplateItem(template, idx);
            container.appendChild(item);
        });
    }

    // Create template item element
    function createTemplateItem(template, idx) {
        const item = document.createElement('div');
        item.className = 'template-item';

        const meta = document.createElement('div');
        meta.innerHTML = `<strong>${escapeHtml(template.name)}</strong><div class="meta">${(template.items || []).length} items</div>`;

        const actions = document.createElement('div');
        const useBtn = createButton('Use', 'addBtn', () => {
            createCategory(template.name, template.items);
            closeTemplates();
        });
        const delBtn = createButton('Delete', 'addBtn', () => {
            templates.splice(idx, 1);
            saveTemplates(templates);
            renderTemplatesList();
        });

        actions.appendChild(useBtn);
        actions.appendChild(delBtn);
        item.appendChild(meta);
        item.appendChild(actions);
        return item;
    }

    // Create category from data
    function createCategory(name, items) {
        const list = document.getElementById('grocery-list');
        const li = document.createElement('li');
        li.className = 'category';

        const header = createCategoryHeader(name, li);
        const subcategory = createSubcategory(items);

        li.appendChild(header);
        li.appendChild(subcategory);
        list.appendChild(li);

        attachHeaderAddButton(li, subcategory);
    }

    // Create category header
    function createCategoryHeader(name, categoryLi) {
        const header = document.createElement('div');
        header.className = 'category-header';

        const dropdown = document.createElement('span');
        dropdown.className = 'dropdown';
        dropdown.textContent = '▸';

        const nameSpan = document.createElement('span');
        nameSpan.className = 'category-name';
        nameSpan.textContent = name;

        const trashSpan = createCategoryTrash(categoryLi);

        header.appendChild(dropdown);
        header.appendChild(nameSpan);
        header.appendChild(trashSpan);
        return header;
    }

    // Create category trash button
    function createCategoryTrash(categoryLi) {
        const trashSpan = document.createElement('span');
        trashSpan.className = 'trash';
        const img = document.createElement('img');
        img.src = '.././icons/trash.png';
        img.alt = 'Delete';
        img.style.width = '16px';
        img.style.height = '16px';
        trashSpan.appendChild(img);
        return trashSpan;
    }

    // Create subcategory with items
    function createSubcategory(items) {
        const subcategory = document.createElement('ul');
        subcategory.className = 'subcategory';
        (items || []).forEach(item => {
            const li = createItemElement(item);
            addItemControls(li);
            subcategory.appendChild(li);
        });
        return subcategory;
    }

    // Create item element
    function createItemElement(item) {
        const li = document.createElement('li');
        const name = typeof item === 'string' ? item : (item.name || '');
        const qty = typeof item === 'object' ? item.qty : null;
        const price = typeof item === 'object' ? item.price : null;

        li.dataset.name = name;
        updateDataset(li, 'qty', qty);
        updateDataset(li, 'price', price);

        const nameSpan = document.createElement('span');
        nameSpan.className = 'item-name';
        nameSpan.textContent = name;

        const leftDiv = document.createElement('div');
        leftDiv.className = 'item-left';
        leftDiv.appendChild(nameSpan);
        leftDiv.appendChild(createMetaDiv(qty, price));
        li.appendChild(leftDiv);

        return li;
    }

    // Helper: Update dataset attribute
    function updateDataset(element, key, value) {
        if (value !== null) {
            element.dataset[key] = value;
        } else {
            delete element.dataset[key];
        }
    }

    // Helper: Parse number input
    function parseNumberInput(id) {
        const value = document.getElementById(id).value;
        return value ? Number(value) : null;
    }

    // Helper: Create button
    function createButton(text, className, onClick) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = className;
        btn.textContent = text;
        btn.addEventListener('click', onClick);
        return btn;
    }

    // Helper: Escape HTML
    function escapeHtml(str) {
        const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
        return String(str).replace(/[&<>"']/g, m => map[m]);
    }

    // LocalStorage helpers
    function loadTemplates() {
        try {
            return JSON.parse(localStorage.getItem('groceryTemplates') || '[]');
        } catch {
            return [];
        }
    }

    function saveTemplates(templates) {
        localStorage.setItem('groceryTemplates', JSON.stringify(templates));
    }
});