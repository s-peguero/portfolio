document.addEventListener("DOMContentLoaded", function () {
    // Pantry pop-up
    window.openPopUp = function () {
        document.getElementById("message").style.display = "flex";
    };
    window.closePopUp = function () {
        document.getElementById("message").style.display = "none";
    };

    //kitchen content inventory filtering and sorting
    const inventory = [
        { name: "Olive Oil", location: "Pantry", quantity: 2 },
        { name: "Onion", location: "Pantry", quantity: 12 },
        { name: "Garlic", location: "Fridge", quantity: 0 },
        { name: "Paprika", location: "Fridge", quantity: 1 },
        { name: "Tomatoes", location: "Fridge", quantity: 5 },
        { name: "Eggs", location: "Fridge", quantity: 23 },
        { name: "Parsley", location: "Fridge", quantity: 0 }
    ];

    const list = document.getElementById("inventoryList");
    let currentFilter = 'all';
    const openSet = new Set();

    function renderInventory(filter = "all") {
        currentFilter = filter;
        list.innerHTML = "";

        inventory.forEach((item, index) => {
            if (filter === "available" && item.quantity <= 0) return;
            if (filter === "pantry" && item.location !== "Pantry") return;
            if (filter === "fridge" && item.location !== "Fridge") return;

            const box = document.createElement("div");
            box.className = "inventory-item";

            const name = document.createElement("h3");
            name.textContent = item.name;
            box.appendChild(name);

            const details = document.createElement("div");
            details.className = "inventory-details";
            details.innerHTML = `
                        <p>Location: ${item.location}</p>
                        <p>Quantity: ${item.quantity}</p>
                        <p>Status: <span class="status-text ${item.quantity > 0 ? 'available' : 'not-available'}">${item.quantity > 0 ? 'Available' : 'Not Available'}</span></p>
                        <button class="qty-plus" data-idx="${index}">+</button>
                        <button class="qty-minus" data-idx="${index}">-</button>
                    `;
            box.appendChild(details);

            details.style.display = openSet.has(index) ? 'block' : 'none';

            box.addEventListener("click", (e) => {
                if (e.target.closest('.inventory-details')) return;
                if (openSet.has(index)) {
                    openSet.delete(index);
                    details.style.display = 'none';
                } else {
                    openSet.add(index);
                    details.style.display = 'block';
                }
            });

            details.querySelectorAll('.qty-plus, .qty-minus').forEach(btn => {
                btn.addEventListener('click', (ev) => {
                    ev.stopPropagation();
                    const idx = parseInt(btn.dataset.idx, 10);
                    const change = btn.classList.contains('qty-plus') ? 1 : -1;
                    adjustQuantity(idx, change);
                });
            });

            list.appendChild(box);
        });
    }

    window.filterInventory = (filter) => { currentFilter = filter; renderInventory(filter); };

    window.adjustQuantity = (index, change) => {
        inventory[index].quantity = Math.max(0, inventory[index].quantity + change);
        // Re-render and keep the item's details open
        renderInventory(currentFilter, index);
    };

    window.openAddItemPopup = () => {
        document.getElementById("addItemPopup").style.display = "block";
    };

    window.closeAddItemPopup = () => {
        document.getElementById("addItemPopup").style.display = "none";
    };

    window.addNewItem = (event) => {
        event.preventDefault();
        const name = document.getElementById("newName").value.trim();
        const location = document.getElementById("newLocation").value;
        const quantity = parseInt(document.getElementById("newQuantity").value, 10);

        if (name && !isNaN(quantity)) {
            inventory.push({ name, location, quantity });
            document.getElementById("addItemForm").reset();
            closeAddItemPopup();
            renderInventory();
        }
    };

    renderInventory();

    // meal planning
    const daySelectorElement = document.getElementById("daySelector");
    const dayContentElement = document.getElementById("dayContent");
    const weekLabelElement = document.getElementById("weekLabel");
    const previousWeekButton = document.getElementById("prevWeekBtn");
    const nextWeekButton = document.getElementById("nextWeekBtn");
    const generatePlanButton = document.getElementById("generateBtn");
    const clearAllButton = document.getElementById("clearAll");
    const exportPlanButton = document.getElementById("exportBtn");
    if (daySelectorElement && dayContentElement) {
        const daysOfWeek = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
        const mealTypes = ["Breakfast", "Lunch", "Dinner"];
        const mealPlanByDay = {};
        daysOfWeek.forEach((dayName) => {
            mealPlanByDay[dayName] = {};
            mealTypes.forEach((mealType) => {
                mealPlanByDay[dayName][mealType] = null;
            });
        });
        let selectedDayName = daysOfWeek[0];
        // week label stuff
        let weekOffsetFromCurrent = 0; // this week
        function getStartOfWeek(offsetFromCurrentWeek) {
            const currentDate = new Date();
            const currentDayIndex = currentDate.getDay();
            const differenceToMonday = currentDayIndex === 0 ? -6 : 1 - currentDayIndex;
            const mondayDate = new Date(currentDate);
            mondayDate.setDate(
                currentDate.getDate() + differenceToMonday + offsetFromCurrentWeek * 7
            );
            mondayDate.setHours(0, 0, 0, 0);
            return mondayDate;
        }
        function updateWeekLabelText() {
            if (!weekLabelElement) return;
            const weekStartDate = getStartOfWeek(weekOffsetFromCurrent);
            const weekEndDate = new Date(weekStartDate);
            weekEndDate.setDate(weekStartDate.getDate() + 6);

            const dateFormatOptions = {
                month: "short",
                day: "numeric",
            };
            weekLabelElement.textContent =
                "Week of " +
                weekStartDate.toLocaleDateString(undefined, dateFormatOptions) +
                " – " +
                weekEndDate.toLocaleDateString(undefined, dateFormatOptions);
        }
        if (previousWeekButton) {
            previousWeekButton.addEventListener("click", function () {
                weekOffsetFromCurrent--;
                updateWeekLabelText();
            });
        }
        if (nextWeekButton) {
            nextWeekButton.addEventListener("click", function () {
                weekOffsetFromCurrent++;
                updateWeekLabelText();
            });
        }
        updateWeekLabelText();
        // day selector
        function renderDaySelectorButtons() {
            daySelectorElement.innerHTML = "";
            daysOfWeek.forEach((dayName) => {
                const dayButton = document.createElement("button");
                dayButton.textContent = dayName;
                dayButton.className =
                    "mealPlannerDayChip" +
                    (dayName === selectedDayName ? " active" : "");
                dayButton.addEventListener("click", function () {
                    selectedDayName = dayName;
                    renderDaySelectorButtons();
                    renderDayContentCards();
                });
                daySelectorElement.appendChild(dayButton);
            });
        }
        // modal/interactive elements 
        const mealPlannerModalElement = document.getElementById("mealModal");
        const modalTitleElement = document.getElementById("modalTitle");
        const modalCloseButton = document.getElementById("modalClose");
        const mealFormElement = document.getElementById("mealForm");
        const mealPresetSelectElement = document.getElementById("mealPreset");
        const mealCustomInputElement = document.getElementById("mealCustom");
        const mealServingsInputElement = document.getElementById("mealServings");
        const mealPrepTimeInputElement = document.getElementById("mealPrepTime");
        const mealNotesInputElement = document.getElementById("mealNotes");
        let editingMealContext = null;
        function openMealPlannerModal(dayName, mealType) {
            if (!mealPlannerModalElement) {
                return;
            }
            editingMealContext =
            {
                dayName: dayName,
                mealType: mealType,
            };
            const existingMeal = mealPlanByDay[dayName][mealType];
            if (existingMeal) {
                modalTitleElement.textContent = "Edit " + mealType;
                // check if existing meal matches one of the current recipes
                const presetValues = Array.from(mealPresetSelectElement.options).map(
                    (optionElement) => optionElement.value
                );
                if (presetValues.includes(existingMeal.name)) {
                    mealPresetSelectElement.value = existingMeal.name;
                    mealCustomInputElement.value = "";
                } else {
                    mealPresetSelectElement.value = "";
                    mealCustomInputElement.value = existingMeal.name || "";
                }
                mealServingsInputElement.value =
                    typeof existingMeal.servings === "number" ?
                        existingMeal.servings :
                        "";
                mealPrepTimeInputElement.value =
                    typeof existingMeal.prepTime === "number" ?
                        existingMeal.prepTime :
                        "";
                mealNotesInputElement.value = existingMeal.notes || "";
            }
            else {
                modalTitleElement.textContent = "Add " + mealType;
                mealFormElement.reset();
                if (mealPresetSelectElement) {
                    mealPresetSelectElement.value = "";
                }
            }
            mealPlannerModalElement.classList.add("open");
        }
        function closeMealPlannerModal() {
            if (!mealPlannerModalElement) {
                return;
            }
            mealPlannerModalElement.classList.remove("open");
            editingMealContext = null;
        }

        if (modalCloseButton) {
            modalCloseButton.addEventListener("click", function () {
                closeMealPlannerModal();
            });
        }

        if (mealPlannerModalElement) {
            mealPlannerModalElement.addEventListener("click", function (event) {
                if (event.target === mealPlannerModalElement) {
                    closeMealPlannerModal();
                }
            });
        }

        if (mealFormElement) {
            mealFormElement.addEventListener("submit", function (event) {
                event.preventDefault();
                if (!editingMealContext) return;

                const dayName = editingMealContext.dayName;
                const mealType = editingMealContext.mealType;

                let mealName = mealPresetSelectElement.value;
                if (!mealName) {
                    mealName = (mealCustomInputElement.value || "").trim();
                }

                if (!mealName) {
                    alert("Please select a recipe or enter a meal name.");
                    return;
                }
                const servingsValueText = mealServingsInputElement.value;
                const prepTimeValueText = mealPrepTimeInputElement.value;
                const notesText = mealNotesInputElement.value.trim();
                mealPlanByDay[dayName][mealType] = {
                    name: mealName,
                    servings: servingsValueText ?
                        parseInt(servingsValueText, 10) : null,
                    prepTime: prepTimeValueText ?
                        parseInt(prepTimeValueText, 10) : null,
                    notes: notesText || "",
                };
                closeMealPlannerModal();
                renderDayContentCards();
            });
        }

        // breakfast, lunch, dinner specific cards
        function renderDayContentCards() {
            dayContentElement.innerHTML = "";
            mealTypes.forEach((mealType) => {
                const mealCardElement = document.createElement("div");
                mealCardElement.className = "mealPlannerCard";
                const mealCardHeaderElement = document.createElement("div");
                mealCardHeaderElement.className = "mealPlannerCardHeader";
                const mealCardTitleElement = document.createElement("h3");
                mealCardTitleElement.className = "mealPlannerCardTitle";
                mealCardTitleElement.textContent = mealType;
                const mealCardActionsElement = document.createElement("div");
                mealCardActionsElement.className = "mealPlannerCardActions";
                mealCardHeaderElement.appendChild(mealCardTitleElement);
                mealCardHeaderElement.appendChild(mealCardActionsElement);
                mealCardElement.appendChild(mealCardHeaderElement);
                const mealData = mealPlanByDay[selectedDayName][mealType];
                if (mealData) {
                    // be able to edit remove etc action buttons
                    const editButton = document.createElement("button");
                    editButton.className = "mealPlannerLinkButton";
                    editButton.textContent = "Edit";
                    editButton.addEventListener("click", function () {
                        openMealPlannerModal(selectedDayName, mealType);
                    });
                    const removeButton = document.createElement("button");
                    removeButton.className =
                        "mealPlannerLinkButton mealPlannerLinkButtonDanger";
                    removeButton.textContent = "Remove";
                    removeButton.addEventListener("click", function () {
                        mealPlanByDay[selectedDayName][mealType] = null;
                        renderDayContentCards();
                    });
                    mealCardActionsElement.appendChild(editButton);
                    mealCardActionsElement.appendChild(removeButton);
                    // general summary
                    const mealSummaryElement = document.createElement("div");
                    mealSummaryElement.className = "mealPlannerMealSummary";
                    const mealAvatarElement = document.createElement("div");
                    mealAvatarElement.className = "mealPlannerMealAvatar";
                    mealAvatarElement.textContent = mealData.name ?
                        mealData.name.charAt(0).toUpperCase() :
                        "?";
                    const mealMainElement = document.createElement("div");
                    mealMainElement.className = "mealPlannerMealMain";
                    const mealNameElement = document.createElement("p");
                    mealNameElement.className = "mealPlannerMealName";
                    mealNameElement.textContent = mealData.name;
                    const mealMetaElement = document.createElement("p");
                    mealMetaElement.className = "mealPlannerMealMeta";
                    const mealDetailsPieces = [];
                    if (mealData.servings) {
                        mealDetailsPieces.push(
                            mealData.servings +
                            " serving" +
                            (mealData.servings > 1 ? "s" : "")
                        );
                    }
                    if (mealData.prepTime || mealData.prepTime === 0) {
                        mealDetailsPieces.push(mealData.prepTime + " min prep");
                    }
                    mealMetaElement.textContent = mealDetailsPieces.join(" · ");
                    mealMainElement.appendChild(mealNameElement);
                    mealMainElement.appendChild(mealMetaElement);
                    mealSummaryElement.appendChild(mealAvatarElement);
                    mealSummaryElement.appendChild(mealMainElement);
                    mealCardElement.appendChild(mealSummaryElement);

                    if (mealData.notes) {
                        const mealNotesElement = document.createElement("p");
                        mealNotesElement.className = "mealPlannerMealNotes";
                        mealNotesElement.textContent = "Notes: " + mealData.notes;
                        mealCardElement.appendChild(mealNotesElement);
                    }
                } else {
                    const emptyMessageElement = document.createElement("p");
                    emptyMessageElement.className = "mealPlannerEmptyMessage";
                    emptyMessageElement.textContent = "No meal planned yet.";
                    mealCardElement.appendChild(emptyMessageElement);

                    const addMealButton = document.createElement("button");
                    addMealButton.className = "mealPlannerAddMealButton";
                    addMealButton.textContent = "+ Add meal";
                    addMealButton.addEventListener("click", function () {
                        openMealPlannerModal(selectedDayName, mealType);
                    });
                    mealCardElement.appendChild(addMealButton);
                }
                dayContentElement.appendChild(mealCardElement);
            });
        }
        // make an example plan if they choose generate
        if (generatePlanButton) {
            generatePlanButton.addEventListener("click", function () {
                const sampleMeals = [{
                    name: "Shakshuka",
                    servings: 2,
                    prepTime: 25,
                    notes: "Serve with toast or pita.",
                },
                {
                    name: "Green Goddess Salad",
                    servings: 1,
                    prepTime: 15,
                    notes: "Add avocado if available.",
                },
                {
                    name: "Grilled Chicken Breast",
                    servings: 2,
                    prepTime: 30,
                    notes: "Marinate the night before.",
                },
                {
                    name: "Beef Ramen",
                    servings: 2,
                    prepTime: 35,
                    notes: "",
                },
                {
                    name: "Alfredo Pasta",
                    servings: 3,
                    prepTime: 20,
                    notes: "Use whole-wheat pasta if preferred.",
                },
                ];

                daysOfWeek.forEach((dayName) => {
                    mealTypes.forEach((mealType) => {
                        const randomSampleMeal =
                            sampleMeals[Math.floor(Math.random() * sampleMeals.length)];
                        mealPlanByDay[dayName][mealType] = {
                            name: randomSampleMeal.name,
                            servings: randomSampleMeal.servings,
                            prepTime: randomSampleMeal.prepTime,
                            notes: randomSampleMeal.notes,
                        };
                    });
                });

                renderDayContentCards();
            });
        }
        // clear everything 
        if (clearAllButton) {
            clearAllButton.addEventListener("click", function () {
                daysOfWeek.forEach((dayName) => {
                    mealTypes.forEach((mealType) => {
                        mealPlanByDay[dayName][mealType] = null;
                    });
                });
                renderDayContentCards();
            });
        }
        // export
        if (exportPlanButton) {
            exportPlanButton.addEventListener("click", function () {
                const dataString = JSON.stringify(mealPlanByDay, null, 2);
                alert("Current plan:\n\n" + dataString);
            });
        }
        // render
        renderDaySelectorButtons();
        renderDayContentCards();
    }


    // Profile Page
    const profileForm = document.getElementById('profile-form');
    const PROFILE_KEY = 'kk_profile';
    if (profileForm) {
        function gatherProfileData() {
            const username = document.getElementById('username')?.value || '';
            const sharing = (document.querySelector('input[name="sharingFridge"]:checked') || {}).value || '';
            const roommates = document.getElementById('roommates')?.value || '';
            const dietaryNodes = Array.from(document.querySelectorAll('input[name="dietary"]'));
            const dietary = dietaryNodes.filter(i => i.checked).map(i => i.value);
            const cuisineNodes = Array.from(document.querySelectorAll('input[name="cuisines"]'));
            const cuisines = cuisineNodes.filter(i => i.checked).map(i => i.value);
            return { username, sharingFridge: sharing, roommates, dietary, cuisines };
        }

        function saveProfile() {
            const data = gatherProfileData();
            try {
                localStorage.setItem(PROFILE_KEY, JSON.stringify(data));
            } catch (e) {
                console.error('Failed to save profile to localStorage', e);
            }
        }

        function loadProfile() {
            try {
                const raw = localStorage.getItem(PROFILE_KEY);
                if (!raw) return;
                const p = JSON.parse(raw);
                if (p.username !== undefined) document.getElementById('username').value = p.username;
                if (p.roommates !== undefined) document.getElementById('roommates').value = p.roommates;
                if (p.sharingFridge !== undefined) {
                    const el = document.querySelector(`input[name="sharingFridge"][value="${p.sharingFridge}"]`);
                    if (el) el.checked = true;
                }
                // checkboxes
                if (Array.isArray(p.dietary)) {
                    document.querySelectorAll('input[name="dietary"]').forEach(i => {
                        i.checked = p.dietary.includes(i.value);
                    });
                }
                if (Array.isArray(p.cuisines)) {
                    document.querySelectorAll('input[name="cuisines"]').forEach(i => {
                        i.checked = p.cuisines.includes(i.value);
                    });
                }
            } catch (e) {
                console.error('Failed to load profile from localStorage', e);
            }
        }

        // Form submit saves
        profileForm.addEventListener('submit', function (e) {
            e.preventDefault();
            saveProfile();
            try {
                const orig = document.getElementById('save-profile');
                if (orig) {
                    const prevText = orig.textContent;
                    orig.textContent = 'Saved!';
                    setTimeout(() => { orig.textContent = prevText; }, 1200);
                } else {
                    alert('Profile saved');
                }
            } catch (err) {
                console.log('Profile saved');
            }
        });

        // Reset button clears the form and removes saved profile from localStorage
        const resetBtn = document.getElementById('reset-profile');
        if (resetBtn) {
            resetBtn.addEventListener('click', function () {
                try {
                    // clear inputs
                    const usernameEl = document.getElementById('username');
                    if (usernameEl) usernameEl.value = '';
                    document.querySelectorAll('input[name="sharingFridge"]').forEach(i => i.checked = false);
                    const roommatesEl = document.getElementById('roommates');
                    if (roommatesEl) roommatesEl.value = '';
                    document.querySelectorAll('input[name="dietary"]').forEach(i => i.checked = false);
                    document.querySelectorAll('input[name="cuisines"]').forEach(i => i.checked = false);
                    // remove saved profile
                    try { localStorage.removeItem(PROFILE_KEY); } catch (e) { }
                } catch (e) {
                    console.error('Failed to reset profile', e);
                    alert('Failed to reset profile');
                }
            });
        }

        loadProfile();
    }
});